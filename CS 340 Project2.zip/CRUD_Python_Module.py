# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from getpass import getpass #import getpass for hidden password input
class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username 
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(host=HOST, port=PORT, username=USER, password=PASS, authSource="admin") # pass connection values seperatly to avoid URI parsing issues with special characters
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            # use the try and except to catch insert errors and return false if the insert fails
            try:
                self.database.animals.insert_one(data)  # data should be dictionary
                return True
            except Exception:
                print("insert failed")
                return False
            
        
        else:
            
           return False
           

    # Created a read method which is the r in crud to find a document
    def read(self, query):
        if query is not None:
            # used the try and except method to return a list or an or results of an empty list if the query is empty or the search failed
            try:
                
        
                result = list(self.database.animals.find(query))
                return result
            except Exception:
                return []
        else:
            return[]
        
        
    # Created an update method which is the U in crud to find and update a document            
    def update(self, query, data):
        
        if query is not None and data is not None:
            try:
                result = self.database.animals.update_one(query,{"$set": data})
                return result.modified_count
            except Exception:
                return 0
        else:
            return 0
        
    # Created a delete method which is the D in crud to find and delete a document  
    def delete(self, query):
        if query is not None:
            try:
                result = self.database.animals.delete_one(query)
                return result.deleted_count
            except Exception:
                return 0
        else:
            return 0
          
        
                
            
                
            
            
       
   
            
                